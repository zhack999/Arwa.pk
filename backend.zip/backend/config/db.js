import dotenv from "dotenv";
dotenv.config();

import pkg from "pg";

const { Pool } = pkg;

console.log("===== DATABASE CONFIG =====");
console.log("Host:", process.env.DB_HOST);
console.log("Port:", process.env.DB_PORT);
console.log("User:", process.env.DB_USER);
console.log("Database:", process.env.DB_NAME);
console.log("Password:", process.env.DB_PASSWORD ? "(set)" : "(missing!)");
console.log("===========================");

const pool = new Pool({
  host: process.env.DB_HOST,
  port: Number(process.env.DB_PORT),
  user: process.env.DB_USER,
  password: String(process.env.DB_PASSWORD),
  database: process.env.DB_NAME,
});

export default pool;