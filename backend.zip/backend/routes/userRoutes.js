import express from "express";
import {
    registerCustomer, loginCustomer, logoutCustomer, checkCustomerAuth, getCustomers,
    updateProfile, changePassword,
    getAddresses, addAddress, updateAddress, deleteAddress, setDefaultAddress,
} from "../controllers/userController.js";
import customerAuthMiddleware from "../middleware/customerAuthMiddleware.js";
import authMiddleware from "../middleware/authMiddleware.js";

const router = express.Router();

// Public — customer-facing auth
router.post("/register", registerCustomer);
router.post("/login", loginCustomer);
router.post("/logout", logoutCustomer);
router.get("/check", customerAuthMiddleware, checkCustomerAuth);

// Customer profile & password (logged-in customer only)
router.put("/profile", customerAuthMiddleware, updateProfile);
router.put("/password", customerAuthMiddleware, changePassword);

// Customer addresses (logged-in customer only)
router.get("/addresses", customerAuthMiddleware, getAddresses);
router.post("/addresses", customerAuthMiddleware, addAddress);
router.put("/addresses/:id", customerAuthMiddleware, updateAddress);
router.delete("/addresses/:id", customerAuthMiddleware, deleteAddress);
router.put("/addresses/:id/default", customerAuthMiddleware, setDefaultAddress);

// Admin-only — list all customers
router.get("/", authMiddleware, getCustomers);

export default router;