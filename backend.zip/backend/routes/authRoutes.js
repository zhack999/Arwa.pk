import express from "express";
import { adminLogin, adminLogout, checkAuth } from "../controllers/authController.js";
import authMiddleware from "../middleware/authMiddleware.js";

const router = express.Router();

router.post("/login", adminLogin);
router.post("/logout", adminLogout);
router.get("/check", authMiddleware, checkAuth);

export default router;