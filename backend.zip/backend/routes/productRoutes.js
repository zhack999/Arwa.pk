import express from "express";

import {
    getProducts,
    getSingleProduct,
    createProduct,
    updateProduct,
    deleteProduct
} from "../controllers/productController.js";

import upload from "../middleware/uploadMiddleware.js";
import authMiddleware from "../middleware/authMiddleware.js";

const router = express.Router();

// ======================================================
// PUBLIC ROUTES
// ======================================================

// Get All Products
router.get("/", getProducts);

// Get Single Product
router.get("/:slug", getSingleProduct);

// ======================================================
// PROTECTED ADMIN ROUTES
// ======================================================

// Create Product
router.post(
    "/",
    authMiddleware,
    upload.single("image"),
    createProduct
);

// Update Product
router.put(
    "/:id",
    authMiddleware,
    upload.single("image"),
    updateProduct
);

// Delete Product
router.delete(
    "/:id",
    authMiddleware,
    deleteProduct
);

export default router;