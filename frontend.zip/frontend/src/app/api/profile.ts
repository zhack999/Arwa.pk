import { apiFetch } from "./client";

export async function updateProfileApi(first_name: string, last_name: string, email: string, phone: string) {
  const data = await apiFetch("/customers/profile", {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ first_name, last_name, email, phone }),
  });
  return data.user;
}

export async function changePasswordApi(oldPassword: string, newPassword: string) {
  await apiFetch("/customers/password", {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ oldPassword, newPassword }),
  });
}