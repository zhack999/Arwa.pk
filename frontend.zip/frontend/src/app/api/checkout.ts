import { apiFetch } from "./client";

export interface CheckoutPayload {
  customer_name: string;
  customer_email: string;
  customer_phone: string;
  shipping_address: string;
  shipping_city: string;
  shipping_province: string;
  shipping_postal?: string;
  payment_method: string;
  shipping_fee: number;
  notes?: string;
  items: { product_id: string; quantity: number }[];
}

export async function placeOrder(payload: CheckoutPayload): Promise<{ order_number: string; total: number }> {
  const data = await apiFetch("/orders", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  return { order_number: data.order.order_number, total: Number(data.order.total) };
}